﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR_Admenstration_api
{
    // declaring the system code interface
    interface Employee_Interface
    {
        #region Interface Attrributes
        int id { get; set; }
        string Fst_name { get; set; }
        string Lst_name { get; set; }
        decimal Salary { get; set; }
        #endregion
    }
}
