﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR_Admenstration_api
{
    class EmployeeTempl
    {
        #region Atribbutes
        public int id { get; set; }
        public string Fst_name { get; set; }
        public string Lst_name { get; set; }
        public virtual decimal Salary { get; set; }// we make it virtual here so we can override
        #endregion

    }
}
