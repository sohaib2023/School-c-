﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR_admenstration
{
   public class EmployeeTEmplate:EmployeeInterface
    {
        #region  template attributes
        public int id { get; set; }
        public string FstName { get; set; }
        public string lstName { get; set; }
        public virtual decimal Salary { get; set; }
        #endregion
    }
}
