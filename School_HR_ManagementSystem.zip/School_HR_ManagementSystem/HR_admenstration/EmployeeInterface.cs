﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR_admenstration
{
    // setting system code interface 
    #region interface Atribbute
    public interface EmployeeInterface
    {
        int id { get; set;}
        string FstName { get; set; }
        string lstName { get; set; }
        decimal Salary { get; set; }
        #endregion
    }
}
